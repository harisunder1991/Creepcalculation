while True:
    print("Enter the total length of the conductor in meters:")
    length_of_conductor = round(float(input()), 2)
    print("Enter the gauge length in meters:")
    gauge_length = round(float(input()), 3)
    a = round((0.25 * gauge_length), 3)
    print(f"Length of a is {a}")
    condition_to_check_as_perstandard = round((gauge_length + (2 * a)), 2)
    if condition_to_check_as_perstandard == length_of_conductor:
        print("The conductor met as per standard")
        break
    else:
        print("The conductor did not meet as per standard gauge")
        print(
            f"Computed total length: {condition_to_check_as_perstandard}, Expected total length: {length_of_conductor}"
        )
        print("Please re-enter the values.")
print("please enter the coe of conductor")
coe_conductor = float(input())
print("please enter the coe of steel")
coe_steel = float(input())
print("please enter the coe of aluminium")
coe_aluminium = float(input())
print(f"The gauge length is {gauge_length}")
steel_bar_length = round((coe_aluminium - coe_conductor) / (coe_aluminium -
                                                      coe_steel) * gauge_length,2)
print(f"The length of steel bar is {steel_bar_length}")
aluminium_bar_length = round(
    (coe_conductor - coe_steel) / (coe_aluminium - coe_steel) * gauge_length,
    2)
print(f"The length of aluminium bar is {aluminium_bar_length}")
